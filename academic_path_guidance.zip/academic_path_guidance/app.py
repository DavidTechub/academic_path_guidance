from flask import Flask, render_template, request
from recommender import load_programmes, score_user

app = Flask(__name__)  # Corrected here
programmes = load_programmes()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    # grab all form inputs into a dict
    user_input = request.form.to_dict()
    # compute recommendations
    recommendations = score_user(user_input, programmes)
    # render the result page
    return render_template('result.html', recommendations=recommendations)

if __name__ == '__main__':  # Corrected here
    app.run(debug=True)
