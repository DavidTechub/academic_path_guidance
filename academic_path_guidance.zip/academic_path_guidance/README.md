# Academic Path Guidance

This project is an *expert system* designed to recommend university career paths based on student grades and interests. It uses a *weighted scoring model* and *educational datasets* to match students with suitable academic fields.

## Features

- *Student Data Input*: Collects grades and interests from students.
- *Career Path Matching*: Suggests the most suitable career paths based on scores.
- *Visual Representation*: Displays career path recommendations with comparisons.
- *Integration with Educational Datasets*: Uses real-world data to improve accuracy.

## How to Run

1. *Clone the repository* to your local machine:
    bash
    git clone https://github.com/your-username/Academic-Path-Guidance.git
    

2. *Install dependencies* using pip:
    bash
    pip install -r requirements.txt
    

3. *Run the application*:
    bash
    python app.py
    

    This will start the server locally, and you can access the app by navigating to http://127.0.0.1:5000/ in your web browser.

## License

This project is licensed under the *MIT License* - see the [LICENSE](LICENSE) file for details.

## Contributing

Feel free to fork this repository and submit a pull request if you have suggestions or improvements!

## Acknowledgments

- Thanks to [source of educational datasets] for providing the data that powers the recommendation system.
- Special thanks to [your lecturer/mentor's name] for their guidance and feedback.