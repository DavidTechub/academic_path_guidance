import json

# Load the university programmes from a JSON file
def load_programmes(path='data/programmes.json'):
    with open(path, 'r') as file:
        return json.load(file)

# Score the user based on their grades and interests
def score_user(user_input, programmes):
    recommendations = []

    for programme in programmes:
        score = 0
        weights = programme["required_subjects"]

        # For each required subject or interest, multiply
        # the user's input by the programme's weight
        for subject, weight in weights.items():
            value = float(user_input.get(subject, 0))
            score += value * weight

        recommendations.append({
            "major": programme["major"],
            "score": round(score, 2),
            "career_path": programme["career_path"]
        })

    # Sort from highest to lowest score
    recommendations.sort(key=lambda x: x["score"], reverse=True)
    return recommendations